<div class="row justify-content-center content-main">
	<div class="col-12 col-md-offset-2">
		<div class="">
			<div class="row justify-content-center row-content-menu">
				<div class="col-8 col-md-offset-2">
					<div class="content-main-parent">
						<div class="row justify-content-left">
							<div class="col-2 image-chevron">
						      	<a href="">
									<img src="<?php echo base_url('asset/image/content/chevronBack.png') ?>">	
								</a>
						    </div>
						    <div class="col-md-offset-4 col-md-10 search-parent">
						    	<form>
								  <div class="form-group has-search search-group">
								    <span class="fa fa-search form-control-feedback search-span "></span>
								    <input type="text" class="form-control search-input" placeholder="Search">
								  </div>
								</form>
						    </div>
						    <div class="col-md-offset-8 col-md-12">
						    	<div class="col-4 image-category">
							      	<a href="">
										<img src="<?php echo base_url('asset/image/menu/coffee.png') ?>">
									</a>
							    </div>
							    <div class="col-4 image-category">
							      	<a href="">
										<img src="<?php echo base_url('asset/image/menu/drink.png') ?>">	
									</a>
							    </div>
							    <div class="col-4 image-category">
							      	<a href="">
										<img src="<?php echo base_url('asset/image/menu/milky.png') ?>">
									</a>
							    </div>
							    <div class="col-4 image-category">
							      	<a href="">
										<img src="<?php echo base_url('asset/image/menu/food.png') ?>">
									</a>
							    </div>
						    </div>
						    <div class="col-12 col-md-offset-2 main-menu-content">
								<div class="content-main-parent">
									<div class="row justify-content-left">
										<div class="col col-md-3 image-menu">
								      	<a href="">
											<img src="<?php echo base_url('asset/image/menu/kopsus-image.png') ?>">
										</a>
										<h1 class="title-order-menu">Classic Coffee</h1>
										<p class="deskipsi">Americano with ice and dolce souce.</p>
										<span class="harga-menu">
											Rp 27.000
											<img src="<?php echo base_url('asset/image/menu/chevron-menu.png') ?>">
										</span>
								    </div>
								    <div class="col col-md-3 image-menu">
								      	<a href="">
											<img src="<?php echo base_url('asset/image/menu/coffee-menu.png') ?>">	
										</a>
										<h1 class="title-order-menu">Classic Coffee</h1>
										<p class="deskipsi">Americano with ice and dolce souce.</p>
										<span class="harga-menu">
											Rp 27.000
											<img src="<?php echo base_url('asset/image/menu/chevron-menu.png') ?>">
										</span>
								    </div>
								    <div class="col col-md-3 image-menu">
								      	<a href="">
											<img src="<?php echo base_url('asset/image/menu/kopsus-image.png') ?>">
										</a>
										<h1 class="title-order-menu">Classic Coffee</h1>
										<p class="deskipsi">Americano with ice and dolce souce.</p>
										<span class="harga-menu">
											Rp 27.000
											<img src="<?php echo base_url('asset/image/menu/chevron-menu.png') ?>">
										</span>
								    </div>
								    <div class="col col-md-3 image-menu">
								      	<a href="">
											<img src="<?php echo base_url('asset/image/menu/coffee-menu.png') ?>">	
										</a>
										<h1 class="title-order-menu">Classic Coffee</h1>
										<p class="deskipsi">Americano with ice and dolce souce.</p>
										<span class="harga-menu">
											Rp 27.000
											<img src="<?php echo base_url('asset/image/menu/chevron-menu.png') ?>">
										</span>
								    </div>
								    <div class="col col-md-3 image-menu">
								      	<a href="">
											<img src="<?php echo base_url('asset/image/menu/kopsus-image.png') ?>">
										</a>
										<h1 class="title-order-menu">Classic Coffee</h1>
										<p class="deskipsi">Americano with ice and dolce souce.</p>
										<span class="harga-menu">
											Rp 27.000
											<img src="<?php echo base_url('asset/image/menu/chevron-menu.png') ?>">
										</span>
								    </div>
								    <div class="col col-md-3 image-menu">
								      	<a href="">
											<img src="<?php echo base_url('asset/image/menu/kopsus-image.png') ?>">
										</a>
										<h1 class="title-order-menu">Classic Coffee</h1>
										<p class="deskipsi">Americano with ice and dolce souce.</p>
										<span class="harga-menu">
											Rp 27.000
											<img src="<?php echo base_url('asset/image/menu/chevron-menu.png') ?>">
										</span>
								    </div>
								    <div class="col col-md-3 image-menu">
								      	<a href="">
											<img src="<?php echo base_url('asset/image/menu/kopsus-image.png') ?>">
										</a>
										<h1 class="title-order-menu">Classic Coffee</h1>
										<p class="deskipsi">Americano with ice and dolce souce.</p>
										<span class="harga-menu">
											Rp 27.000
											<img src="<?php echo base_url('asset/image/menu/chevron-menu.png') ?>">
										</span>
								    </div>
								    <div class="col col-md-3 image-menu">
								      	<a href="">
											<img src="<?php echo base_url('asset/image/menu/kopsus-image.png') ?>">
										</a>
										<h1 class="title-order-menu">Classic Coffee</h1>
										<p class="deskipsi">Americano with ice and dolce souce.</p>
										<span class="harga-menu">
											Rp 27.000
											<img src="<?php echo base_url('asset/image/menu/chevron-menu.png') ?>">
										</span>
								    </div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-4 col-md-offset-2">
					<div class="">
						<div class="row justify-content-center">
							<div class="card shadow mb-4 card-dash card-detail-order">
					            <!-- Card Header - Accordion -->
					            <a href="#collapseCardStock" class="d-block card-header py-3 card-header-menu" data-toggle="collapse"
					                role="button" aria-expanded="true" aria-controls="collapseCardStock">
					                <div class="title-cards">
					                	Detail Pesanan
					                </div>
					                <div class="title-cards-sub">
					                	Pesanan No. 31
					                </div>
					            </a>
					            <!-- Card Content - Collapse -->
					            <div class="collapse show collapse-parent-detail" id="collapseCardStock">
					                <table class="table table-striped">
									  <thead>
									    <tr>
									      <th scope="col">Menu</th>
									      <th scope="col">Jumlah</th>
									      <th scope="col">Jumlah</th>
									    </tr>
									  </thead>
									  <tbody>
									    <tr>
									      <th scope="row">1</th>
									      <td>Mark</td>
									      <td>Otto</td>
									    </tr>
									    <tr>
									      <th scope="row">2</th>
									      <td>Jacob</td>
									      <td>Thornton</td>
									    </tr>
									    <tr>
									      <th scope="row">3</th>
									      <td>Larry</td>
									      <td>the Bird</td>
									    </tr>
									    <tr>
									      <th scope="row">3</th>
									      <td>Larry</td>
									      <td>the Bird</td>
									    </tr>
									    <tr>
									      <th scope="row">3</th>
									      <td>Larry</td>
									      <td>the Bird</td>
									    </tr>
									    <tr>
									      <th scope="row">3</th>
									      <td>Larry</td>
									      <td>the Bird</td>
									    </tr>
									    <tr>
									      <th scope="row">3</th>
									      <td>Larry</td>
									      <td>the Bird</td>
									    </tr>
									    <tr>
									      <th scope="row">3</th>
									      <td>Larry</td>
									      <td>the Bird</td>
									    </tr>
									    <tr>
									      <th scope="row">3</th>
									      <td>Larry</td>
									      <td>the Bird</td>
									    </tr>
									  </tbody>
									</table>
					            </div>
					        </div>
					        <div class="card-dash">
								<div class="form-group">	
							    	<span class="h6 small bg-white text-muted pt-1 pl-2 pr-2 label-order">
							    		Name<span class="require-notice">*</span>
							    	</span>
									<input type="text" class="form-control mt-n3 order-input" id="input1" placeholder="Nama Pelanggan">
								</div>
								<div class="form-group">	
							    	<span class="h6 small bg-white text-muted pt-1 pl-2 pr-2 label-order">
							    		Email atau Nomor Handphone<span class="require-notice">*</span>
							    	</span>
									<input type="text" class="form-control mt-n3 order-input" id="input1" placeholder="Nama Pelanggan">
								</div>
								<div>
									<button type="button" class="btn btn-primary btn-order-payment">Metode Pembayaran</button>
								</div>
					        </div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>	